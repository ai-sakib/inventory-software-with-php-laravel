<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers;
use App\Models\Supplier;

class SupplierController extends Controller
{
  
    public function index()
    {
        $suppliers=Supplier::orderBy('id','desc')->get();
        return view('admin.supplier.index',compact('suppliers'));
    }

   
    public function create(){   
        return view('admin.supplier.create');
    }

    public function store(Request $request, Supplier $supplier )
    {
        $this->validate($request, [
            'name'=> 'required',
            'address'=> 'required',
            'phone'=> 'required',
            'email'=> 'required',
        ]);
        $supplier->fill($request->all());
        $supplier->uid = uniqueCode(10,'c-','uid','items');
        $supplier->save();
        if($supplier) {    
            session()->flash('success', 'Cutomer has been added Successfully');
            $file=$request->file('file');
            if(isset($file)){
                $fileInfo=fileInfo($file);
                $image=$supplier->id.'-'.date('YmdHis').'.'.$fileInfo['extension']; 
                $upload=fileUpload($file,'suppliers',$image);
                Supplier::where('id',$supplier->id)->update(['image'=>$image]);
            }
        }else{
            session()->flash('error', 'Something Went Wrong !');
        }
        return redirect()->back();
    }
    
    public function edit($id)
    {
        $supplier = Supplier::find($id);
        return view('admin.supplier.edit', compact('supplier'));
    }

    public function update(Request $request, $id)
    {
          $this->validate($request, [
            'name'=> 'required',
            'address'=> 'required',
            'phone'=> 'required',
            'email'=> 'required',
        ]);
        $supplier = Supplier::find($id);
        $supplier->fill($request->all());
        $supplier->save();
        if($supplier) {    
            session()->flash('success', 'Cutomer has been updated Successfully');
            $file=$request->file('file');
            if(isset($file)){
                if($supplier->image != "" && file_exists(public_path('suppliers/').$supplier->image)){
                    unlink(public_path('suppliers/').$supplier->image);
                }
                $fileInfo=fileInfo($file);
                $image=$supplier->id.'-'.date('YmdHis').'.'.$fileInfo['extension']; 
                $upload=fileUpload($file,'suppliers',$image);
                Supplier::where('id',$supplier->id)->update(['image'=>$image]);
            }
        }else{
            session()->flash('error', 'Something Went Wrong !');
        }
        return redirect()->back();
    }
    public function show($data)
    {
        $id = explode('&', $data)[0];
        $status = explode('&', $data)[1];

        Supplier::find($id)->update(['status'=>$status]);
        
        return response()->json([
            'success'=>true, 
            'status'=>$status,
            'id'=>$id,
        ]);
    }
   
    public function destroy($id){
        $supplier = Supplier::find($id);
        $delete = $supplier->delete();
        if($delete) {
            if($supplier->image != "" && file_exists(public_path('suppliers/').$supplier->image)){
                unlink(public_path('suppliers/').$supplier->image);
            }
            return response()->json(["success" => true]);
        }else{
            return response()->json(["success" => false]);
        }
    }
}
