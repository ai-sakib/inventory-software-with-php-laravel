<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers;
use App\Models\Project;
use Illuminate\Support\Facades\Hash;

use Auth;

class ProjectController extends Controller
{
  
    public function index()
    {
        $project=Project::find(1);
        return view('admin.project.index',compact('project'));
    }
    public function changePassword()
    {
        return view('admin.project.changePassword');
    }
    public function forgetPassword()
    {
        return view('admin.project.forgetPassword');
    }
    public function changePasswordStore(Request $request)
    {
        $this->validate($request,[
            'old_password' => 'required',
            'new1_password' => 'required',
            'confirm_password' => 'required',
        ]);

        if(Hash::check($request->old_password, Auth()->user()->password)) {
            if($request->new1_password != $request->confirm_password){
                session()->flash('error', 'Sorry ! password did not matched !');
            }else{
                Auth()->user()->password = Hash::make($request->new1_password);
                Auth()->user()->save();
                session()->flash('success', 'Password Changed !');
            }
        }else{
            session()->flash('error', 'Sorry ! wrong password !');
        }
        
        return redirect()->back();
    }

    public function store(Request $request){
        $this->validate($request,[
            'name',
            'email',
            'phone',
            'address',
        ]);

        $project = Project::find(1);
        $project->fill($request->all())->save();
        if($project) {    
            session()->flash('success', 'Project details has been updated Successfully');
            if(isset($project)){
                $file=$request->file('file');
                if(isset($file)){
                    if($project->logo != "" && file_exists(public_path('project/').$project->logo)){
                        unlink(public_path('project/').$project->logo);
                    }
                    $fileInfo=fileInfo($file);
                    $logo= $project->name.'-'.date('YmdHis').'.'.$fileInfo['extension']; 
                    $upload=fileUpload($file,'project',$logo);
                    Project::find(1)->update(['logo'=>$logo]);
                }
                return redirect()->back();
            }
            return redirect()->back();
        }else{
            session()->flash('error', 'Something Went Wrong !');
            return redirect()->back();
        }
    }
   
}
